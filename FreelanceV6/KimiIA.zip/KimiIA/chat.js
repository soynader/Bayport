const messages = document.getElementById('messages');
const input    = document.getElementById('input');
const sendBtn  = document.getElementById('sendBtn');

const GROQ_API_KEY = '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'; // <-- Cambiar
const MODEL = 'llama3-70b-8192';

sendBtn.onclick = sendMessage;
input.addEventListener('keydown', e => { if (e.key === 'Enter') sendMessage(); });

async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;
  appendMessage(text, 'user');
  input.value = '';
  const reply = await askGroq(text);
  appendMessage(reply, 'bot');
}

function appendMessage(text, cls) {
  const div = document.createElement('div');
  div.className = cls;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

async function askGroq(question) {
  const prompt = `Eres un asesor experto de Bayport Colombia. Responde en máximo 60 palabras usando el siguiente contexto:\n${KNOWLEDGE}\n\nPregunta: ${question}`;
  try {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 120,
        temperature: 0.2
      })
    });
    const data = await res.json();
    return data.choices?.[0]?.message?.content || 'Sin respuesta';
  } catch (e) {
    return 'Error al conectar con IA. Revisá tu clave o conexión.';
  }
}