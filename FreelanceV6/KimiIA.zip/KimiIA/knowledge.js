// Pega aquí TODO el Markdown anterior
const KNOWLEDGE = `
# 🚀 Kit de Asesoría Freelance – Bayport Colombia
...
`;   // ← Copiá todo el contenido